<div class="box-content">
	<?php Painel::alert('erro','Você não tem permissão para visualizar esta página!'); ?>
</div><!--box-content-->